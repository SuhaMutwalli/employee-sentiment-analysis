# Employee Sentiment Analysis

**Author:** Suha Mutwalli  
**Email:** suhamutwalli786@gmail.com

## Overview
This project performs sentiment analysis on employee messages. The notebook uses both **VADER** and **TextBlob** for sentiment labeling, generates visualizations, and saves results for review.

## Files in the Project
- `employee_sentiment_analysis.ipynb` — Main notebook
- `test.csv` — Dataset file
- `results/` — Contains CSV outputs (VADER and TextBlob labeled datasets)
- `visualization/` — Contains plots and charts
- `README.md` — Project documentation
- `requirements.txt` — Python dependencies
- `.env.example` — Example environment variables

## Instructions to Run
1. Place `employee_sentiment_analysis.ipynb` and `test.csv` in the same folder.
2. Open the notebook in Jupyter Notebook, JupyterLab, or VS Code.
3. Run all cells from top to bottom.
4. After execution:
   - Labeled datasets will be in `results/`
   - Charts and visualizations will be in `visualization/`

## Methodology
- **VADER**: Used for initial sentiment labeling of employee messages.
- **TextBlob**: Added as a secondary sentiment analysis tool (added after VADER cell). 
- Messages are categorized as `Positive`, `Negative`, or `Neutral`.
- Visualizations include sentiment distribution and other EDA charts.

## Notes
- The notebook automatically creates `results/` and `visualization/` folders if they do not exist.
- Required packages are listed in `requirements.txt`.
- Example environment variables are in `.env.example`.
